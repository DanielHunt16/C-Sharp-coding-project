﻿using System;

namespace Dofe_application
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello");
            Console.WriteLine("Press any key to continue");
            Console.ReadKey(true);
            Console.WriteLine("What is your name?");
            var name = Console.ReadLine();
            Console.WriteLine($"Your name is: {name} ");
            Console.ReadKey(true);
        }
    }
}
