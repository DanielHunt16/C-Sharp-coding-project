﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Orgranzier
{
    public partial class Form2 : Form
    {
        string direct = @"C:\Users\Public\Code Dictionary\";
        
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                System.IO.Directory.CreateDirectory(direct);
            }
            catch (System.IO.IOException)
            {
                return;
            }

            string head = textBox1.Text;
            string body = textBox2.Text;
            string example = textBox3.Text;
            string name = head + ".txt";
                        
            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(direct + name))
            {

                file.WriteLine(head);
                file.WriteLine(body);
                file.WriteLine(example);

            }
           
            Form1 openForm = new Form1();
            openForm.Show();
            Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
