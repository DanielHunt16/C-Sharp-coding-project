﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Orgranzier
{
    public partial class Form3 : Form
    {
        string head = null;
        string body = null;
        string example = null;

        string direct = @"C:\Users\Public\Code Dictionary\";

        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                System.IO.Directory.CreateDirectory(direct);
            }
            catch (System.IO.IOException)
            {
                MessageBox.Show("Word does not exist");
                return;
            }
            String input = textBox1.Text;
            String search = input + ".txt";


            using (System.IO.StreamReader file =
           new System.IO.StreamReader(direct + search))
            {

                head = file.ReadLine();
                body = file.ReadLine();
                example = file.ReadLine();

            }

            textBox4.Text = head;
            textBox2.Text = body;
            textBox3.Text = example;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            string nhead = textBox1.Text;
            string nbody = textBox2.Text;
            string nexample = textBox3.Text;
            string name = nhead + ".txt";

            using (System.IO.StreamWriter file =
            new System.IO.StreamWriter(direct + name))
            {

                file.WriteLine(head);
                file.WriteLine(body);
                file.WriteLine(example);
                File.Delete(direct + search);

            }
        }
    }
}
