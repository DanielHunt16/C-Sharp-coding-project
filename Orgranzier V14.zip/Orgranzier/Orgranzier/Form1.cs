﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Orgranzier
{
    public partial class Form1 : Form
    {
        string head = "null";
        string body = "null";

        string direct = @"c:\Users\Public";

        
               
        



        public Form1()
        {
            InitializeComponent();
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            
            String input = textBox1.Text;
            String search = input + ".txt";
            MessageBox.Show(search);

            using (System.IO.StreamReader file =
           new System.IO.StreamReader(@"D:\Files\Documents\Code Dict\" +  search))
            {

                head = file.ReadLine();
                body = file.ReadLine();

            }

            MessageBox.Show(body);
            MessageBox.Show(head);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 openForm = new Form2();
            openForm.Show();
            Visible = false;
        }
    }
}
