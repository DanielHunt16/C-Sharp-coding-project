﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Orgranzier
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int num = random.Next(0, 10000);

            string head = textBox1.Text;
            string body = textBox2.Text;
            string name = head + ".txt";

            using (StreamWriter writer = new StreamWriter(name))
            {
                writer.Write(head);
                writer.Write(body);
            }
            MessageBox.Show(name);
            Form1 openForm = new Form1();
            openForm.Show();
            Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
