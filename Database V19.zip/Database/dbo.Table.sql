﻿CREATE TABLE [dbo].[Table]
(
	[Name] TEXT NOT NULL PRIMARY KEY, 
    [Age] TEXT NOT NULL, 
    [Gender] NCHAR(10) NULL, 
    [Birthday] DATETIME2 NOT NULL
)
