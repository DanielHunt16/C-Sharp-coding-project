﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Orgranzier
{
    public partial class Form1 : Form
    {
        string head = null;
        string body = null;
        string example = null;

        string direct = @"C:\Users\Public\Code Dictionary\";
                    
        
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button2_Click(object sender, EventArgs e)
        {
            System.IO.Directory.CreateDirectory(direct);
            
            String input = textBox1.Text;
            String search = input + ".txt";

            try
            {
                using (System.IO.StreamReader file =
               new System.IO.StreamReader(direct + search))
                {

                    head = file.ReadLine();
                    body = file.ReadLine();
                    example = file.ReadLine();

                }
            } 
            catch(System.IO.IOException)
            {
                MessageBox.Show("Word does not exist");
                return;

            }

                label1.Text = head;
            label2.Text = body;
            label6.Text = example;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 openForm = new Form2();
            openForm.Show();
            Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 openForm = new Form3();
            openForm.Show();
            Visible = false;
        }
    }
}
