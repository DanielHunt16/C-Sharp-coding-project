﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Experiment2
{
    
    public partial class Form2 : Form
    {
                
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }
        string Operation { get; set; }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Operation = listBox1.GetItemText(listBox1.SelectedItem);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        public string Numone { get; set; }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Numone = textBox1.Text;
            //int.Parse(Numone);
        }
        public string Numtwo { get; set; }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Numtwo = textBox2.Text;
            //.Parse(Numtwo);
        }
        string answer { get; set; }
        public int NumoneInt { get; private set; }
        public int NumtwoInt { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
            NumoneInt = Convert.ToInt32(Numone);
            NumtwoInt = Convert.ToInt32(Numtwo);




            if (Operation == "Add")
            { int answer = NumoneInt + NumtwoInt; }
            else if (Operation == "Subtract")
            { int answer = NumoneInt - NumtwoInt; }
            else if (Operation == "Multiply")
            { int answer = NumoneInt * NumtwoInt; }
            else if (Operation == "Divide")
            { int answer = NumoneInt / NumtwoInt; }
            else
            {  answer = "error"; }   

            string Sanswer = answer.ToString();

            MessageBox.Show(Sanswer);
        }

       
    }
}
