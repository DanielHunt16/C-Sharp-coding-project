﻿using System;
using System.Threading;

namespace Dofe_application
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine();
            Console.WriteLine("Hello");
            Thread.Sleep(2000);
            Console.WriteLine("Press any key to continue");
            Console.ReadKey(true);
            Console.WriteLine("What is your name?");
            var name = Console.ReadLine();
            Console.WriteLine($"Your name is: {name} ");
            Thread.Sleep(2000);
            Console.WriteLine("First number:");
            Random rnd = new Random();
            int num = rnd.Next(1, 10);
            Console.WriteLine(num);
            Console.ReadKey(true);

        }
    }

}




