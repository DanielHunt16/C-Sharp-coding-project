﻿//using System;

//used a test program


//namespace Dofe_application
//{
//    class ProgramParttwo
//    {

//        static void Main(string[] args)
//        {
//            Random rnd = new Random();
//            int month = rnd.Next(1, 13); // creates a number between 1 and 12
//            int dice = rnd.Next(1, 7);   // creates a number between 1 and 6
//            int card = rnd.Next(52);

//            Console.WriteLine(month);
//            Console.ReadKey(true);

//        }

//    }
//}
