﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace Database_V2
{
    public partial class Form1 : Form
    {
        string directr = "Users.xml";


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string Age = textBox2.Text;
            string Gender = textBox3.Text;

            //try
            //{
              //  XmlWriter xmlWriter = XmlWriter.Create("Users.xml");

               // xmlWriter.WriteStartDocument();
                //xmlWriter.WriteStartElement("users");
                //xmlWriter.WriteEndDocument();
                //xmlWriter.Close();
           // }
           // catch (System.IO.IOException)
          //  {
              //  return;
          //  }

            if(File.Exists(directr))
            {
                XDocument doc = XDocument.Load(directr);
                XElement users = doc.Element("users");
                users.Add(new XElement(Name,
                          new XElement("Age", Age),
                          new XElement("Gender", Gender)));
                doc.Save(directr);
                MessageBox.Show("Success");

            }
            else
            {
                XmlWriter xmlWriter = XmlWriter.Create("Users.xml");

                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement("users");
                xmlWriter.WriteStartElement(Name);
                xmlWriter.WriteStartElement("Age");
                xmlWriter.WriteString(Age);
                xmlWriter.WriteEndElement();
                xmlWriter.WriteStartElement("Gender");
                xmlWriter.WriteString(Gender);
                xmlWriter.WriteEndElement();
                xmlWriter.WriteEndDocument();
                xmlWriter.Close();
                MessageBox.Show("Success");
            }













            //XmlWriter xmlWriter2 = XmlWriter.

            // xmlWriter2.WriteStartDocument();
            //xmlWriter2.WriteStartElement("users");
            // xmlWriter2.WriteEndDocument();
            //xmlWriter2.Close();


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
